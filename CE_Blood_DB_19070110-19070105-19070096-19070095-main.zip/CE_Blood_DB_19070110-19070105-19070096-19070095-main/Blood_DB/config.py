AUTHY_API_KEY = "MLx9YYu6xahifd98iNtSyzTeYpKYi0ZM"
SECRET_KEY = 'moisecretttk33y'

